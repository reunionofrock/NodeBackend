CREATE DATABASE personas
GO
CREATE TABLE tb_persona(
	id_persona INT IDENTITY(1,1),
	nombre VARCHAR(40) NOT NULL,
	apellido VARCHAR(40) NOT NULL,
	CONSTRAINT pk_persona 
		PRIMARY KEY (id_persona)
)
GO