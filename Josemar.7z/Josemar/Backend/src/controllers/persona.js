const sql = require('mssql');

let conn = {
    server: "DELL_INSPIRON\\DEVELOPMENT",
    database: "personas",
    user: "sa",
    password: "Guatemala2022",
    pool:{
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
}

exports.obtenerPersonas = async(req,res) =>{
    try{
        let pool = await sql.connect(conn);
        console.log(pool);
        let resultado = await pool.request().query('select * from tb_persona')
        
        if( resultado.recordset.length > 0) {res.json(resultado.recordset)}
        else {res.json({ msj: 'No hay personas registradas'})}
    }
    catch(e){
        console.log(e);
        res.send('Ha ocurrido un error');
    }
}

exports.guardarPersona = async(req,res) =>{
    try{
        let pool = await sql.connect(conn);

        await pool.request().query(`insert into tb_persona(nombre,apellido) 
                                            values ('${req.body.nombre}','${req.body.apellido}')`);
        res.send('Persona guardad');
    }
    catch(e){
        console.log(e);
        res.send('Ha ocurrido un error');
    }
}