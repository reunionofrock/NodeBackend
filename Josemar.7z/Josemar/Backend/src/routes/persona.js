const express = require('express');
const router = express.Router();
const persona = require('../controllers/persona')

router.get('/obtener-personas',persona.obtenerPersonas);
router.post('/guardar-persona',persona.guardarPersona);

module.exports = router;

//http://localhost:3000/api/obtener-personas