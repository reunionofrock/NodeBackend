const express = require('express');
const app = express();
const persona = require('./routes/persona');

app.use(express.json());

app.use('/api',persona);

app.listen(3000, () =>{console.log('Servidor iniciado');});